import 'package:flutter/material.dart';
import 'package:payment/order.dart'; // Import your Order model

class OrderProvider with ChangeNotifier {
  List<Order> _activeOrders = [];
  List<Order> _historyOrders = [];

  List<Order> get activeOrders => _activeOrders;
  List<Order> get historyOrders => _historyOrders;

  void addOrder(Order order) {
    _activeOrders.add(order);
    notifyListeners();
  }

  void completeOrder(Order order) {
    order.status = 'Delivered';
    _activeOrders.remove(order);
    _historyOrders.add(order);
    notifyListeners();
  }
}
