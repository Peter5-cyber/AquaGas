class Order {
  final String id;
  String status;

  Order({required this.id, required this.status});
}
