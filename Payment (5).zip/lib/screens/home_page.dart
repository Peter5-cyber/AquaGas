import 'package:flutter/material.dart';
// Removed: import 'package:carousel_slider/carousel_slider.dart';
import 'cart_screen.dart';
import '../cart.dart';
import 'order_screen.dart';
import 'profile_screen.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;
  int _currentCarouselIndex = 0;
  final List<String> _carouselImages = [
    'assets/promotion1.jpg',
    'assets/promotion2.jpg',
    'assets/promotion3.jpg',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('AquaGas'),
        backgroundColor: Colors.blueAccent,
        actions: [
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {
              showSearch(context: context, delegate: CustomSearchDelegate());
            },
          ),
          IconButton(
            icon: Icon(Icons.shopping_cart),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => CartPage()),
              );
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: ProfileScreen(),
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          int crossAxisCount = constraints.maxWidth > 600 ? 3 : 2;
          double mainAxisSpacing = constraints.maxWidth > 600 ? 24.0 : 16.0;
          double crossAxisSpacing = constraints.maxWidth > 600 ? 24.0 : 16.0;

          return SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Replaced _buildCarouselSlider with a placeholder or removed it
                // _buildCarouselSlider(),
                _buildCategoryFilter(),
                _buildSectionTitle('Accessories'),
                _buildGridView(
                    crossAxisCount, mainAxisSpacing, crossAxisSpacing, [
                  _buildProductCard('6kg Regulator', 825.00,
                      'assets/gas_cylinder_13kg.jpeg', 4.5),
                  _buildProductCard('13kg Regulator', 750.00,
                      'assets/gas_cylinder_13kg.jpeg', 4.0),
                  _buildProductCard(
                      'Burner', 830.00, 'assets/gas_cylinder_6kg.jpeg', 4.3),
                  _buildProductCard(
                      'Grill', 320.00, 'assets/gas_cylinder_6kg.jpeg', 4.8),
                ]),
                _buildSectionTitle('Gas Cylinders'),
                _buildGridView(
                    crossAxisCount, mainAxisSpacing, crossAxisSpacing, [
                  _buildProductCard('6kg Gas Cylinder', 1500.00,
                      'assets/gas_cylinder_6kg.jpeg', 4.7),
                  _buildProductCard('13kg Gas Cylinder', 3000.00,
                      'assets/gas_cylinder_13kg.jpeg', 4.3),
                ]),
                _buildSectionTitle('Top Brands'),
                _buildBrandListView(),
              ],
            ),
          );
        },
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.location_on),
            label: 'Nearby',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_cart),
            label: 'Cart',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.receipt_long),
            label: 'Orders',
          ),
        ],
        currentIndex: _selectedIndex,
        unselectedItemColor: Colors.grey,
        selectedItemColor: Colors.blueAccent,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
          if (index == 2) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => CartPage()),
            );
          } else if (index == 3) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => OrderScreen()),
            );
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Quick action
        },
        child: Icon(Icons.add),
        backgroundColor: Colors.blueAccent,
      ),
    );
  }

  // Removed: Widget _buildCarouselSlider() {
  //   return CarouselSlider(
  //     options: CarouselOptions(
  //       height: 200.0,
  //       autoPlay: true,
  //       onPageChanged: (index, reason) {
  //         setState(() {
  //           _currentCarouselIndex = index;
  //         });
  //       },
  //     ),
  //     items: _carouselImages.map((imagePath) {
  //       return Builder(
  //         builder: (BuildContext context) {
  //           return Container(
  //             width: MediaQuery.of(context).size.width,
  //             decoration: BoxDecoration(
  //               borderRadius: BorderRadius.circular(12.0),
  //               image: DecorationImage(
  //                 image: AssetImage(imagePath),
  //                 fit: BoxFit.cover,
  //               ),
  //             ),
  //           );
  //         },
  //       );
  //     }).toList(),
  //   );
  // }

  Widget _buildCategoryFilter() {
    return Container(
      height: 60,
      padding: EdgeInsets.symmetric(vertical: 8.0),
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: 16.0),
        children: [
          _buildCategoryChip('All'),
          _buildCategoryChip('Accessories'),
          _buildCategoryChip('Gas Cylinders'),
          _buildCategoryChip('Brands'),
        ],
      ),
    );
  }

  Widget _buildCategoryChip(String label) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Chip(
        label: Text(label),
        backgroundColor: Colors.blueAccent,
        labelStyle: TextStyle(color: Colors.white),
        padding: EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Container(
      padding: EdgeInsets.all(16.0),
      alignment: Alignment.centerLeft,
      child: Text(
        title,
        style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _buildGridView(int crossAxisCount, double mainAxisSpacing,
      double crossAxisSpacing, List<Widget> items) {
    return GridView.count(
      shrinkWrap: true,
      crossAxisCount: crossAxisCount,
      physics: NeverScrollableScrollPhysics(),
      mainAxisSpacing: mainAxisSpacing,
      crossAxisSpacing: crossAxisSpacing,
      padding: EdgeInsets.symmetric(horizontal: 16.0),
      children: items,
    );
  }

  Widget _buildBrandListView() {
    return Container(
      height: 100,
      padding: EdgeInsets.symmetric(horizontal: 16.0),
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          _buildBrandCard('Brand 1', Colors.yellow),
          _buildBrandCard('Brand 2', Colors.red),
          _buildBrandCard('Brand 3', Colors.green),
          _buildBrandCard('Brand 4', Colors.blue),
        ],
      ),
    );
  }

  Widget _buildBrandCard(String title, Color color) {
    return Container(
      width: 100,
      margin: EdgeInsets.only(right: 16.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8.0),
        color: color,
      ),
      child: Center(child: Text(title, style: TextStyle(color: Colors.white))),
    );
  }

  Widget _buildProductCard(
      String title, double price, String imagePath, double rating) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
      elevation: 4.0,
      child: Column(
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.vertical(top: Radius.circular(12.0)),
              child: Image.asset(imagePath,
                  fit: BoxFit.cover, width: double.infinity),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                Text(
                  title,
                  style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
                ),
                Text(
                  'KES $price',
                  style: TextStyle(fontSize: 14.0, color: Colors.grey),
                ),
                SizedBox(height: 4.0),
                _buildRatingStars(rating),
                SizedBox(height: 8.0),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      cart.addItem({'title': title, 'price': price});
                    });
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('$title added to cart')),
                    );
                  },
                  child: Text('Add to cart'),
                  style: ElevatedButton.styleFrom(
                    primary: Colors.blueAccent,
                    onPrimary: Colors.white,
                    textStyle: TextStyle(fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRatingStars(double rating) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(5, (index) {
        return Icon(
          index < rating ? Icons.star : Icons.star_border,
          color: Colors.yellow,
          size: 16.0,
        );
      }),
    );
  }
}

class CustomSearchDelegate extends SearchDelegate {
  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
        icon: Icon(Icons.clear),
        onPressed: () {
          query = '';
        },
      ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      icon: Icon(Icons.arrow_back),
      onPressed: () {
        close(context, null);
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    // Implement search result UI here
    return Container();
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    // Implement search suggestion UI here
    return Container();
  }
}
