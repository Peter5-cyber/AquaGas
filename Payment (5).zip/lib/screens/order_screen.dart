import 'package:flutter/material.dart';

class Order {
  final String id;
  String status;

  Order({required this.id, required this.status});
}

class OrderScreen extends StatefulWidget {
  @override
  _OrderScreenState createState() => _OrderScreenState();
}

class _OrderScreenState extends State<OrderScreen> {
  // List of orders
  List<Order> activeOrders = [];
  List<Order> historyOrders = [];

  // Simulate order confirmation and completion
  void confirmOrder() {
    setState(() {
      // Add a new order to active orders
      activeOrders.add(Order(id: '123', status: 'Active'));
    });
  }

  void completeOrder(Order order) {
    setState(() {
      // Update the order status and move it to history orders
      order.status = 'Delivered';
      activeOrders.remove(order);
      historyOrders.add(order);
    });
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text('My Orders'),
          bottom: TabBar(
            tabs: [
              Tab(text: 'Active Orders'),
              Tab(text: 'History Orders'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            ActiveOrdersView(
              orders: activeOrders,
              onCompleteOrder: completeOrder,
            ),
            HistoryOrdersView(orders: historyOrders),
          ],
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: confirmOrder,
          child: Icon(Icons.add),
        ),
      ),
    );
  }
}

class ActiveOrdersView extends StatelessWidget {
  final List<Order> orders;
  final Function(Order) onCompleteOrder;

  ActiveOrdersView({required this.orders, required this.onCompleteOrder});

  @override
  Widget build(BuildContext context) {
    if (orders.isEmpty) {
      return Center(
        child: Text('No active orders'),
      );
    }

    return ListView.builder(
      itemCount: orders.length,
      itemBuilder: (context, index) {
        final order = orders[index];
        return ListTile(
          title: Text('Order ID: ${order.id}'),
          subtitle: Text('Status: ${order.status}'),
          trailing: ElevatedButton(
            onPressed: () {
              onCompleteOrder(order);
            },
            child: Text('Mark as Delivered'),
          ),
        );
      },
    );
  }
}

class HistoryOrdersView extends StatelessWidget {
  final List<Order> orders;

  HistoryOrdersView({required this.orders});

  @override
  Widget build(BuildContext context) {
    if (orders.isEmpty) {
      return Center(
        child: Text('No history orders'),
      );
    }

    return ListView.builder(
      itemCount: orders.length,
      itemBuilder: (context, index) {
        final order = orders[index];
        return ListTile(
          title: Text('Order ID: ${order.id}'),
          subtitle: Text('Status: ${order.status}'),
        );
      },
    );
  }
}
