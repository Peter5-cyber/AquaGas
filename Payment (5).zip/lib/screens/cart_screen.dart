import 'package:flutter/material.dart';
import '../cart.dart';
import 'payment_options_screen.dart';
import '../screens/home_page.dart';

class CartPage extends StatefulWidget {
  @override
  _CartPageState createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  String promoCode = '';
  double discount = 0.0;
  String deliveryTime = 'ASAP';
  String selectedTime = '';

  @override
  void initState() {
    super.initState();
    selectedTime = '25 - 35 minutes'; // Default ASAP time
  }

  void applyPromoCode() {
    // This is a placeholder function. Replace with actual promo code logic.
    if (promoCode == 'DISCOUNT10') {
      setState(() {
        discount = cart.totalAmount * 0.1; // 10% discount
      });
    } else {
      setState(() {
        discount = 0.0;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Invalid promo code')),
      );
    }
  }

  void selectDeliveryTime(String time) {
    setState(() {
      deliveryTime = time;
      if (time == 'ASAP') {
        selectedTime = '25 - 35 minutes';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Cart Items'),
      ),
      body: buildCartContent(context),
    );
  }

  Widget buildCartContent(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          if (cart.items.isEmpty)
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'No items found in cart.',
                    style: TextStyle(fontSize: 18.0),
                  ),
                  SizedBox(height: 20.0),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => HomePage()),
                      );
                    },
                    child: Text('Continue Shopping'),
                    style: ElevatedButton.styleFrom(
                      primary: Colors.green,
                      onPrimary: Colors.white,
                    ),
                  ),
                ],
              ),
            )
          else
            ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: cart.items.length,
              itemBuilder: (context, index) {
                var item = cart.items[index];
                return Card(
                  margin: EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
                  child: ListTile(
                    leading: Image.network(
                      item['image'] ?? 'https://via.placeholder.com/150',
                      width: 50,
                      height: 50,
                      fit: BoxFit.cover,
                    ),
                    title: Text(item['title']),
                    subtitle:
                        Text('KES ${item['price']} x ${item['quantity']}'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(Icons.remove_circle, color: Colors.red),
                          onPressed: () {
                            setState(() {
                              cart.removeItem(item);
                            });
                          },
                        ),
                        Text('${item['quantity']}'),
                        IconButton(
                          icon: Icon(Icons.add_circle, color: Colors.green),
                          onPressed: () {
                            setState(() {
                              cart.addItem(item);
                            });
                          },
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Promo Code',
                  style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 10.0),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        decoration: InputDecoration(
                          labelText: 'Enter promo code',
                          border: OutlineInputBorder(),
                        ),
                        onChanged: (value) {
                          promoCode = value;
                        },
                      ),
                    ),
                    SizedBox(width: 10.0),
                    ElevatedButton(
                      onPressed: applyPromoCode,
                      child: Text('Apply'),
                      style: ElevatedButton.styleFrom(
                        primary: Colors.orange,
                        onPrimary: Colors.white,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20.0),
                Text(
                  'Delivery Time',
                  style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
                ),
                Row(
                  children: [
                    Expanded(
                      child: ListTile(
                        title: const Text('ASAP'),
                        leading: Radio<String>(
                          value: 'ASAP',
                          groupValue: deliveryTime,
                          onChanged: (String? value) {
                            selectDeliveryTime(value!);
                          },
                        ),
                      ),
                    ),
                    Expanded(
                      child: ListTile(
                        title: const Text('Schedule'),
                        leading: Radio<String>(
                          value: 'Schedule',
                          groupValue: deliveryTime,
                          onChanged: (String? value) {
                            selectDeliveryTime(value!);
                            if (value == 'Schedule') {
                              showTimePickerDialog(context);
                            }
                          },
                        ),
                      ),
                    ),
                  ],
                ),
                if (deliveryTime == 'ASAP')
                  Text('Estimated delivery time: $selectedTime'),
                if (deliveryTime == 'Schedule' && selectedTime.isNotEmpty)
                  Text('Scheduled delivery time: $selectedTime'),
                SizedBox(height: 20.0),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Total',
                          style: TextStyle(
                              fontSize: 16.0, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          'KES ${(cart.totalAmount - discount).toStringAsFixed(2)}',
                          style:
                              TextStyle(fontSize: 18.0, color: Colors.black87),
                        ),
                        if (discount > 0)
                          Text(
                            'Discount applied: KES ${discount.toStringAsFixed(2)}',
                            style: TextStyle(
                              fontSize: 14.0,
                              color: Colors.green,
                            ),
                          ),
                      ],
                    ),
                    ElevatedButton.icon(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PaymentOptionsScreen(),
                          ),
                        );
                      },
                      icon: Icon(Icons.receipt_long),
                      label: Text('Confirm Order'),
                      style: ElevatedButton.styleFrom(
                        primary: Colors.green,
                        onPrimary: Colors.white,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> showTimePickerDialog(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null && picked != TimeOfDay.now()) {
      setState(() {
        selectedTime = picked.format(context);
      });
    }
  }
}
