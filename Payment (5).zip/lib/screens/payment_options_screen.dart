import 'package:flutter/material.dart';
import '../cart.dart';
import 'payment_confirmation_screen.dart';
import 'add_new_card_screen.dart';

class PaymentOptionsScreen extends StatefulWidget {
  @override
  _PaymentOptionsScreenState createState() => _PaymentOptionsScreenState();
}

class _PaymentOptionsScreenState extends State<PaymentOptionsScreen> {
  bool termsAccepted = false;
  String selectedPaymentOption = 'Visa';
  bool showSummary = false;
  String phoneNumber = '';
  double deliveryFee = 200.0;
  final List<String> savedCards = [
    '**** **** **** 3789',
    '**** **** **** 5345'
  ];
  final Cart cart =
      Cart(); // Assuming Cart is a class with totalAmount property

  void _toggleSummaryScreen() {
    setState(() {
      showSummary = !showSummary;
    });
  }

  void _confirmPayment() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Confirm Payment'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Payment Method: $selectedPaymentOption'),
              Text('Amount to Pay: KES ${cart.totalAmount + deliveryFee}'),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => PaymentConfirmationScreen(
                      paymentOption: selectedPaymentOption,
                    ),
                  ),
                );
              },
              child: const Text('Proceed'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(showSummary ? 'Summary' : 'Pay for AquaGas'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: _toggleSummaryScreen,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child:
            showSummary ? _buildSummaryScreen() : _buildPaymentOptionsScreen(),
      ),
    );
  }

  Widget _buildPaymentOptionsScreen() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildLocationInfo(),
          const SizedBox(height: 20.0),
          _buildSectionTitle('Saved Payment'),
          const SizedBox(height: 10.0),
          ..._buildSavedPaymentOptions(),
          if (selectedPaymentOption == 'MPESA') _buildMpesaPhoneNumberField(),
          const SizedBox(height: 20.0),
          _buildSectionTitle('Add Payment Method'),
          const SizedBox(height: 10.0),
          _buildAddPaymentMethodTile(),
          const SizedBox(height: 20.0),
          _buildSectionTitle('Order Summary'),
          const Divider(),
          _buildOrderSummary(),
          const SizedBox(height: 20.0),
          _buildProceedButton(),
        ],
      ),
    );
  }

  Widget _buildLocationInfo() {
    return Container(
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Colors.green[100],
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            "Your Location",
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          TextButton(
            onPressed: () {
              // Handle location change
            },
            child: const Text('Change'),
            style: TextButton.styleFrom(primary: Colors.orange),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
    );
  }

  List<Widget> _buildSavedPaymentOptions() {
    return savedCards.map((card) {
      String cardType = card.contains('Visa') ? 'Visa' : 'Mastercard';
      return _buildPaymentOptionTile(
        'assets/mpesa_logo.png', // Use appropriate card logos
        '$cardType $card',
        selectedPaymentOption == cardType,
        () {
          setState(() {
            selectedPaymentOption = cardType;
          });
        },
      );
    }).toList()
      ..add(
        _buildPaymentOptionTile(
          'assets/mpesa_logo.png',
          'MPESA',
          selectedPaymentOption == 'MPESA',
          () {
            setState(() {
              selectedPaymentOption = 'MPESA';
            });
          },
        ),
      );
  }

  Widget _buildMpesaPhoneNumberField() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10.0),
      child: TextField(
        decoration: const InputDecoration(
          labelText: 'Enter MPESA Phone Number',
          border: OutlineInputBorder(),
        ),
        keyboardType: TextInputType.phone,
        onChanged: (value) {
          setState(() {
            phoneNumber = value;
          });
        },
      ),
    );
  }

  Widget _buildAddPaymentMethodTile() {
    return ListTile(
      leading: const Icon(Icons.credit_card),
      title: const Text('Add Credit Card'),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => AddNewCardScreen()),
        );
      },
    );
  }

  Widget _buildOrderSummary() {
    return Column(
      children: [
        ListTile(
          title: const Text('Subtotal'),
          trailing: Text('KES ${cart.totalAmount}'),
        ),
        ListTile(
          title: const Text('Delivery Fee'),
          trailing: Text('KES $deliveryFee'),
        ),
        ListTile(
          title: const Text('Discount'),
          trailing: const Text('KES 0.0'),
        ),
        const Divider(),
        ListTile(
          title: const Text('Total'),
          trailing: Text(
            'KES ${cart.totalAmount + deliveryFee}',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
      ],
    );
  }

  Widget _buildProceedButton() {
    return ElevatedButton(
      onPressed: _toggleSummaryScreen,
      child: const Text('Proceed to Summary'),
      style: ElevatedButton.styleFrom(
        primary: Colors.green,
        onPrimary: Colors.white,
      ),
    );
  }

  Widget _buildSummaryScreen() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        ListTile(
          title: const Text('Total Products Amount'),
          subtitle: Text('KES ${cart.totalAmount}'),
        ),
        ListTile(
          title: const Text('Delivery Fee'),
          subtitle: Text('KES $deliveryFee'),
        ),
        ListTile(
          title: const Text('Total Amount to Pay'),
          subtitle: Text('KES ${cart.totalAmount + deliveryFee}'),
        ),
        const SizedBox(height: 20.0),
        ElevatedButton(
          onPressed: _confirmPayment,
          child: const Text('Confirm Payment'),
          style: ElevatedButton.styleFrom(
            primary: Colors.green,
            onPrimary: Colors.white,
          ),
        ),
      ],
    );
  }

  Widget _buildPaymentOptionTile(
    String assetPath,
    String title,
    bool isSelected,
    VoidCallback onTap,
  ) {
    return ListTile(
      leading: Image.asset(assetPath, width: 50.0),
      title: Text(title),
      trailing: isSelected
          ? const Icon(Icons.check_circle, color: Colors.green)
          : null,
      tileColor: isSelected ? Colors.green[50] : null,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8.0),
        side: BorderSide(
          color: isSelected ? Colors.green : Colors.grey,
          width: isSelected ? 2 : 1,
        ),
      ),
      onTap: onTap,
    );
  }
}
