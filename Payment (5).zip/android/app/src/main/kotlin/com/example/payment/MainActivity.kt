package com.example.payment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
